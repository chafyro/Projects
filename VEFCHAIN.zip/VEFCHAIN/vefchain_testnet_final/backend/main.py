
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Optional
import time, hashlib, json

app = FastAPI()

# Blockchain logic
class VEFBlock:
    def __init__(self, index, timestamp, problem, solution, solve_steps, verify_steps, staker, previous_hash, reward, transfers, zk_proof=None):
        self.index = index
        self.timestamp = timestamp
        self.problem = problem
        self.solution = solution
        self.solve_steps = solve_steps
        self.verify_steps = verify_steps
        self.vef = solve_steps / verify_steps if verify_steps else 0
        self.reward = reward
        self.transfers = transfers
        self.staker = staker
        self.previous_hash = previous_hash
        self.zk_proof = zk_proof or {}
        self.hash = self.compute_hash()

    def compute_hash(self):
        block_data = json.dumps(self.__dict__, sort_keys=True, default=str).encode()
        return hashlib.sha256(block_data).hexdigest()

class VEFBlockchain:
    def __init__(self):
        self.chain: List[VEFBlock] = []
        self.stakers: Dict[str, float] = {}
        self.create_genesis_block()

    def create_genesis_block(self):
        genesis = VEFBlock(0, time.time(), "GENESIS", "", 1, 1, "genesis", "0", 0, [])
        self.chain.append(genesis)

    def add_block(self, problem, solution, solve_steps, verify_steps, staker, zk_proof=None):
        last_block = self.chain[-1]
        epoch = len(self.chain)
        vef = solve_steps / verify_steps if verify_steps else 0
        reward = min(vef * (50 / (2 ** (epoch // 50))), 1000)
        new_block = VEFBlock(
            index=epoch,
            timestamp=time.time(),
            problem=problem,
            solution=solution,
            solve_steps=solve_steps,
            verify_steps=verify_steps,
            staker=staker,
            previous_hash=last_block.hash,
            reward=reward,
            transfers=[],
            zk_proof=zk_proof
        )
        self.chain.append(new_block)
        self.stakers[staker] = self.stakers.get(staker, 0) + reward
        return new_block

blockchain = VEFBlockchain()

class Submission(BaseModel):
    problem: str
    solution: str
    solve_steps: int
    verify_steps: int
    staker: str
    zk_proof: Optional[dict] = {}

@app.get("/chain")
def get_chain():
    return [block.__dict__ for block in blockchain.chain]

@app.post("/submit")
def submit_solution(data: Submission):
    if data.solve_steps <= 0 or data.verify_steps <= 0:
        raise HTTPException(status_code=400, detail="Invalid step counts")
    block = blockchain.add_block(
        problem=data.problem,
        solution=data.solution,
        solve_steps=data.solve_steps,
        verify_steps=data.verify_steps,
        staker=data.staker,
        zk_proof=data.zk_proof
    )
    return block.__dict__

@app.get("/balance/{staker}")
def get_balance(staker: str):
    return {"staker": staker, "balance": blockchain.stakers.get(staker, 0)}

# Task + Validator logic
tasks = [
    {"id": "task1", "type": "subset_sum", "data": {"nums": [3, 5, 9, 1, 12], "target": 16}},
    {"id": "task2", "type": "knapsack", "data": {"weights": [2, 3, 4], "values": [4, 5, 6], "capacity": 5}},
    {"id": "task3", "type": "3sat", "data": {"clauses": [[1, -2, 3], [-1, 2, -3]], "num_vars": 3}}
]

@app.get("/tasks")
def get_tasks():
    return tasks

class TaskSubmission(BaseModel):
    task_id: str
    solution: List[int]
    staker: str
    solve_steps: int

@app.post("/validate")
def validate_submission(sub: TaskSubmission):
    task = next((t for t in tasks if t['id'] == sub.task_id), None)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    verified = False
    reward_value = 0

    if task['type'] == 'subset_sum':
        verified = sum(sub.solution) == task['data']['target'] and all(i in task['data']['nums'] for i in sub.solution)
        reward_value = len(sub.solution)
    elif task['type'] == 'knapsack':
        w = sum(task['data']['weights'][i] for i in sub.solution)
        verified = w <= task['data']['capacity']
        reward_value = sum(task['data']['values'][i] for i in sub.solution) if verified else 0
    elif task['type'] == '3sat':
        assignment = sub.solution
        verified = all(any((assignment[abs(l)-1] if l > 0 else not assignment[abs(l)-1]) for l in clause) for clause in task['data']['clauses'])
        reward_value = len(task['data']['clauses'])

    if not verified:
        raise HTTPException(status_code=400, detail="Solution failed verification")

    vef = sub.solve_steps / reward_value if reward_value else float('inf')
    return {
        "task_id": sub.task_id,
        "staker": sub.staker,
        "verified": verified,
        "solve_steps": sub.solve_steps,
        "verify_steps": reward_value,
        "vef": round(vef, 2),
        "message": "Solution verified. Submit this to the chain with these values."
    }
